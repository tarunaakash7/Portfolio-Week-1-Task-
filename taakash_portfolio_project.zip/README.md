# T Aakash Portfolio Website

A modern portfolio website showcasing skills, projects, education, certifications, and achievements.

## Features
- Responsive Design
- Dynamic Skills Section
- Project Showcase
- Experience Timeline
- Education Details
- Certifications
- Contact Information

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Author
Tarun Aakash
