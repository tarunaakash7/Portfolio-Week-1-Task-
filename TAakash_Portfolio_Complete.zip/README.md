# T Aakash Portfolio Website

Professional portfolio website showcasing skills, projects, experience,
education, certifications and achievements.

## Technologies
- HTML5
- CSS3
- JavaScript

## Author
Tarun Aakash
